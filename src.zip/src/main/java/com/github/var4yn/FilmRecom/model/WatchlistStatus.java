package com.github.var4yn.FilmRecom.model;

public enum WatchlistStatus {
    PLAN_TO_WATCH,
    WATCHING,
    COMPLETED,
    DROPPED
} 
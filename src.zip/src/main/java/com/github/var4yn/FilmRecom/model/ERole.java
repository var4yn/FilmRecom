package com.github.var4yn.FilmRecom.model;

public enum ERole {
    ROLE_USER,      // Обычный пользователь
    ROLE_MODERATOR,
    ROLE_ADMIN      // Администратор
}
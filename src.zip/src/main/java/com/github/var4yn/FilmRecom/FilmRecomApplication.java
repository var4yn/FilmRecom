package com.github.var4yn.FilmRecom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilmRecomApplication {
	public static void main(String[] args) {
		SpringApplication.run(FilmRecomApplication.class, args);
	}

}

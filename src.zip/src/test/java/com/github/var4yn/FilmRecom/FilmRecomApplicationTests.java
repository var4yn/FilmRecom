package com.github.var4yn.FilmRecom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilmRecomApplicationTests {

	@Test
	void contextLoads() {
	}

}
